DROP TABLE PREFIXiqitadditionaltab;
DROP TABLE PREFIXiqitadditionaltab_lang;
DROP TABLE PREFIXiqitadditionaltab_shop;

